# Changelog

All the changes made to Showcase theme for Hugo.

## v1.2.0 - 2021-07-18

### Added

- Add color customization for Intro and Social links blocks

## v1.1.0 - 2021-07-17

### Added

- Add support for text search

## v1.0.0 - 2021-07-16

- Initial Release